// GameCard.jsx — Reusable card shown on the home screen
import "./GameCard.css";

export default function GameCard({ icon, title, desc, onPlay }) {
  return (
    <div className="gcard" onClick={onPlay}>
      <div className="gcard-icon">{icon}</div>
      <div className="gcard-title">{title}</div>
      <div className="gcard-desc">{desc}</div>
      <button
        className="gcard-play"
        onClick={(e) => {
          e.stopPropagation();
          onPlay();
        }}
      >
        Play Now →
      </button>
    </div>
  );
}
