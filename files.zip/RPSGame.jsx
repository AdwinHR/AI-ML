// RPSGame.jsx — Rock Paper Scissors vs CPU
import { useState } from "react";
import "./RPSGame.css";

const RPS_EMOJI = { rock: "✊", paper: "✋", scissors: "✌️" };
const RPS_OPTS  = ["rock", "paper", "scissors"];

export default function RPSGame() {
  const [scores, setScores] = useState({ you: 0, cpu: 0, draw: 0 });
  const [round, setRound]   = useState(null); // { you, cpu, result }

  function play(choice) {
    const cpu = RPS_OPTS[Math.floor(Math.random() * 3)];

    // Determine winner
    let result;
    if (choice === cpu) {
      result = "draw";
    } else if (
      (choice === "rock"     && cpu === "scissors") ||
      (choice === "paper"    && cpu === "rock")     ||
      (choice === "scissors" && cpu === "paper")
    ) {
      result = "win";
    } else {
      result = "lose";
    }

    setRound({ you: choice, cpu, result });
    setScores((s) => ({
      you:  result === "win"  ? s.you  + 1 : s.you,
      cpu:  result === "lose" ? s.cpu  + 1 : s.cpu,
      draw: result === "draw" ? s.draw + 1 : s.draw,
    }));
  }

  const resultText =
    !round ? "" :
    round.result === "win"  ? "🏆 You Win!"    :
    round.result === "lose" ? "💀 CPU Wins!"   : "🤝 It's a Draw!";

  const resultColor =
    !round ? "" :
    round.result === "win"  ? "var(--teal)" :
    round.result === "lose" ? "var(--red)"  : "var(--muted)";

  return (
    <div className="panel">
      {/* Scoreboard */}
      <div className="score-row">
        <div className="score-box"><span className="val">{scores.you}</span><div className="lbl">YOU</div></div>
        <div className="score-box"><span className="val">{scores.draw}</span><div className="lbl">DRAW</div></div>
        <div className="score-box"><span className="val">{scores.cpu}</span><div className="lbl">CPU</div></div>
      </div>

      {/* Choice buttons */}
      <div className="rps-choices">
        {RPS_OPTS.map((o) => (
          <button
            key={o}
            className={`rps-btn${round?.you === o ? " you" : ""}${round?.cpu === o ? " cpu" : ""}`}
            onClick={() => play(o)}
          >
            {RPS_EMOJI[o]}
            <span>{o.toUpperCase()}</span>
          </button>
        ))}
      </div>

      {/* VS panel */}
      {round && (
        <>
          <div className="rps-vs">
            <div className="rps-pick">
              <span className="big">{RPS_EMOJI[round.you]}</span>
              <div className="sub">YOU</div>
            </div>
            <div className="rps-divider">VS</div>
            <div className="rps-pick">
              <span className="big">{RPS_EMOJI[round.cpu]}</span>
              <div className="sub">CPU</div>
            </div>
          </div>
          <div className="rps-result" style={{ color: resultColor }}>{resultText}</div>
        </>
      )}

      <div style={{ textAlign: "center", marginTop: 12 }}>
        <button
          className="btn btn-ghost btn-sm"
          onClick={() => { setScores({ you: 0, cpu: 0, draw: 0 }); setRound(null); }}
        >
          Reset Scores
        </button>
      </div>
    </div>
  );
}
