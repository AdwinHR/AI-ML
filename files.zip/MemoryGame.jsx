// MemoryGame.jsx — 4×4 flip-to-match card game
import { useState, useEffect, useRef } from "react";
import "./MemoryGame.css";

const EMOJIS = ["🍕", "🎸", "🚀", "🐙", "🌈", "🦊", "💎", "🎩"];

// Fisher-Yates shuffle
function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export default function MemoryGame() {
  const [cards, setCards]     = useState([]);
  const [flipped, setFlipped] = useState([]);   // indices currently face-up
  const [matched, setMatched] = useState([]);   // matched emoji values
  const [moves, setMoves]     = useState(0);
  const [time, setTime]       = useState(0);
  const [running, setRunning] = useState(false);
  const [lock, setLock]       = useState(false); // prevent clicking during check
  const [won, setWon]         = useState(false);
  const timerRef = useRef(null);

  // Init on mount
  useEffect(() => { initGame(); }, []);

  // Timer
  useEffect(() => {
    if (running) {
      timerRef.current = setInterval(() => setTime((t) => t + 1), 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [running]);

  function initGame() {
    clearInterval(timerRef.current);
    const deck = shuffle([...EMOJIS, ...EMOJIS]).map((emoji, i) => ({ id: i, emoji }));
    setCards(deck);
    setFlipped([]); setMatched([]); setMoves(0); setTime(0);
    setRunning(false); setLock(false); setWon(false);
  }

  function flipCard(i) {
    // Guard: locked, already flipped, or already matched
    if (lock || flipped.includes(i) || matched.includes(cards[i].emoji)) return;

    // Start timer on first flip
    if (!running) setRunning(true);

    const next = [...flipped, i];
    setFlipped(next);

    if (next.length === 2) {
      setMoves((m) => m + 1);
      setLock(true);
      const [a, b] = next;

      if (cards[a].emoji === cards[b].emoji) {
        // ✅ Match found
        const newMatched = [...matched, cards[a].emoji];
        setTimeout(() => {
          setMatched(newMatched);
          setFlipped([]);
          setLock(false);
          if (newMatched.length === EMOJIS.length) {
            setRunning(false);
            setWon(true);
          }
        }, 500);
      } else {
        // ❌ No match — flip back after delay
        setTimeout(() => { setFlipped([]); setLock(false); }, 900);
      }
    }
  }

  const fmtTime = (s) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <>
      {/* Stats bar */}
      <div className="mem-stats">
        <div className="stat-box"><strong>{moves}</strong><span>Moves</span></div>
        <div className="stat-box"><strong>{fmtTime(time)}</strong><span>Time</span></div>
        <div className="stat-box"><strong>{matched.length}/8</strong><span>Pairs</span></div>
      </div>

      {/* Card grid */}
      <div className="mem-grid">
        {cards.map((card, i) => {
          const isFlipped = flipped.includes(i);
          const isMatched = matched.includes(card.emoji);
          return (
            <div
              key={card.id}
              className={`mcard${isFlipped ? " flipped" : ""}${isMatched ? " matched" : ""}`}
              onClick={() => flipCard(i)}
            >
              <div className="mcard-inner">
                <div className="mcard-front">❓</div>
                <div className="mcard-back">{card.emoji}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Win banner */}
      {won && (
        <div className="win-banner">
          <h3>🎉 You Won!</h3>
          <p>Completed in {moves} moves and {fmtTime(time)}</p>
          <button className="btn btn-teal" style={{ marginTop: 16 }} onClick={initGame}>
            Play Again
          </button>
        </div>
      )}

      <div style={{ marginTop: 14, textAlign: "right" }}>
        <button className="btn btn-ghost btn-sm" onClick={initGame}>Restart</button>
      </div>
    </>
  );
}
