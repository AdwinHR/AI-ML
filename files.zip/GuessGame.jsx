// GuessGame.jsx — Guess the Number with custom range selector
import { useState, useRef } from "react";
import "./GuessGame.css";

// Quick-pick presets
const PRESETS = [
  { label: "1 – 10",   min: 1, max: 10   },
  { label: "1 – 50",   min: 1, max: 50   },
  { label: "1 – 100",  min: 1, max: 100  },
  { label: "1 – 500",  min: 1, max: 500  },
  { label: "1 – 1000", min: 1, max: 1000 },
  { label: "Custom",   min: null, max: null },
];

export default function GuessGame() {
  // ── Setup state ──
  const [phase, setPhase]         = useState("setup"); // "setup" | "playing"
  const [presetIdx, setPresetIdx] = useState(2);       // default: 1–100
  const [minVal, setMinVal]       = useState(1);
  const [maxVal, setMaxVal]       = useState(100);
  const [customMin, setCustomMin] = useState("");
  const [customMax, setCustomMax] = useState("");

  // ── Game state ──
  const [secret, setSecret]     = useState(null);
  const [guess, setGuess]       = useState("");
  const [attempts, setAttempts] = useState(0);
  const [feedback, setFeedback] = useState({ msg: "", cls: "" });
  const [history, setHistory]   = useState([]);
  const [lo, setLo]             = useState(1);
  const [hi, setHi]             = useState(100);
  const [won, setWon]           = useState(false);
  const [shake, setShake]       = useState(false);

  const inputRef = useRef(null);

  // Apply a preset (or switch to custom)
  function applyPreset(i) {
    setPresetIdx(i);
    const p = PRESETS[i];
    if (p.min !== null) { setMinVal(p.min); setMaxVal(p.max); }
  }

  // Start the game with the chosen range
  function startGame() {
    const mn = presetIdx === 5 ? parseInt(customMin) : minVal;
    const mx = presetIdx === 5 ? parseInt(customMax) : maxVal;
    if (!mn && mn !== 0 || !mx || mn >= mx) return;
    const s = Math.floor(Math.random() * (mx - mn + 1)) + mn;
    setSecret(s);
    setMinVal(mn); setMaxVal(mx);
    setLo(mn); setHi(mx);
    setAttempts(0); setHistory([]); setGuess("");
    setFeedback({ msg: "", cls: "" }); setWon(false);
    setPhase("playing");
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  // Evaluate a guess
  function submitGuess() {
    const g = parseInt(guess);
    if (!g && g !== 0 || g < minVal || g > maxVal) { triggerShake(); return; }
    const a = attempts + 1;
    setAttempts(a);
    setHistory((h) => [...h, { n: a, val: g }]);

    if (g === secret) {
      setFeedback({ msg: `🎉 Correct! It was ${secret}! (${a} attempt${a === 1 ? "" : "s"})`, cls: "win" });
      setWon(true);
    } else if (g > secret) {
      setFeedback({ msg: "⬇️  Too High!", cls: "high" });
      setHi((h) => Math.min(h, g - 1));
      triggerShake();
    } else {
      setFeedback({ msg: "⬆️  Too Low!", cls: "low" });
      setLo((l) => Math.max(l, g + 1));
      triggerShake();
    }
    setGuess("");
    if (!won) setTimeout(() => inputRef.current?.focus(), 50);
  }

  function triggerShake() {
    setShake(true);
    setTimeout(() => setShake(false), 400);
  }

  // How much of the range is left (drives the progress bar)
  const barPct = Math.max(2, Math.round(((hi - lo) / (maxVal - minVal)) * 100));

  // ── SETUP PHASE ──
  if (phase === "setup") return (
    <div className="panel range-setup">
      <div className="preset-section">
        <div className="field-label" style={{ marginBottom: 8 }}>Quick presets</div>
        <div className="preset-row">
          {PRESETS.map((p, i) => (
            <button
              key={i}
              className={`preset${presetIdx === i ? " active" : ""}`}
              onClick={() => applyPreset(i)}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Custom inputs */}
      {presetIdx === 5 ? (
        <div className="range-row">
          <div className="field-group">
            <div className="field-label">Min</div>
            <input type="number" value={customMin} onChange={(e) => setCustomMin(e.target.value)} placeholder="e.g. 1" />
          </div>
          <div className="field-group">
            <div className="field-label">Max</div>
            <input type="number" value={customMax} onChange={(e) => setCustomMax(e.target.value)} placeholder="e.g. 500" />
          </div>
        </div>
      ) : (
        <div className="range-display">
          <span className="range-display-label">Range:</span>
          <span className="range-display-val">{minVal} → {maxVal}</span>
        </div>
      )}

      <button className="btn btn-gold" style={{ marginTop: 6 }} onClick={startGame}>
        Start Game →
      </button>
    </div>
  );

  // ── PLAYING PHASE ──
  return (
    <>
      <div className={`panel${shake ? " shake" : ""}`}>
        {/* Status badges */}
        <div className="badges-row">
          <span className="badge badge-gold">Attempts: {attempts}</span>
          <span className="badge badge-blue">Range: {lo} – {hi}</span>
          <span className="badge badge-teal">Window: {minVal}–{maxVal}</span>
        </div>

        {/* Narrowing range bar */}
        <div className="range-bar-wrap">
          <div className="range-bar-fill" style={{ width: `${barPct}%` }} />
        </div>
        <div className="range-labels">
          <span>{lo}</span>
          <span>{hi}</span>
        </div>

        {/* Guess input */}
        {!won && (
          <div className="guess-input-row">
            <input
              ref={inputRef}
              type="number"
              value={guess}
              onChange={(e) => setGuess(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitGuess()}
              placeholder={`Guess between ${lo} and ${hi}…`}
              min={minVal}
              max={maxVal}
            />
            <button className="btn btn-gold" onClick={submitGuess}>Go</button>
          </div>
        )}

        {/* Feedback message */}
        <div className={`feedback${feedback.cls ? " " + feedback.cls : ""}`}>
          {feedback.msg}
        </div>

        {/* Action buttons */}
        <div className="action-row">
          <button className="btn btn-ghost btn-sm" onClick={() => setPhase("setup")}>
            Change Range
          </button>
          <button className="btn btn-ghost btn-sm" onClick={startGame}>
            New Game
          </button>
        </div>
      </div>

      {/* Guess history chips */}
      {history.length > 0 && (
        <div className="chips">
          {history.map((h) => (
            <span
              key={h.n}
              className={`badge ${
                h.val === secret ? "badge-teal" : h.val > secret ? "badge-red" : "badge-blue"
              }`}
            >
              #{h.n}: {h.val}
            </span>
          ))}
        </div>
      )}
    </>
  );
}
