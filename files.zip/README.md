# 🕹️ Mini Arcade — React

Three fully interactive mini games built with React 18 + Vite.

## Games
- 🎯 **Guess the Number** — pick a preset or custom range, then guess away
- ✊ **Rock Paper Scissors** — you vs CPU with live scoreboard
- 🃏 **Memory Cards** — 4×4 flip-to-match with move & timer tracking

## File Structure
```
mini-arcade/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    └── components/
        ├── GameCard.jsx
        ├── GameCard.css
        ├── GuessGame.jsx
        ├── GuessGame.css
        ├── RPSGame.jsx
        ├── RPSGame.css
        ├── MemoryGame.jsx
        └── MemoryGame.css
```

## Run Locally
```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open in browser
# → http://localhost:5173
```

## Build for Production
```bash
npm run build
npm run preview
```
