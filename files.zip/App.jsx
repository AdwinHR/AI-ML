import { useState } from "react";
import GameCard from "./components/GameCard";
import GuessGame from "./components/GuessGame";
import RPSGame from "./components/RPSGame";
import MemoryGame from "./components/MemoryGame";
import "./App.css";

const GAMES = [
  {
    id: "guess",
    icon: "🎯",
    title: "Guess the Number",
    desc: "Pick your range — from 1–10 to totally custom. The game narrows in on your answer round by round.",
  },
  {
    id: "rps",
    icon: "✊",
    title: "Rock Paper Scissors",
    desc: "The classic showdown vs a machine that never tilts. Who wins? You decide.",
  },
  {
    id: "memory",
    icon: "🃏",
    title: "Memory Cards",
    desc: "Flip a 4×4 grid and find all 8 matching pairs. Track your moves and beat the clock.",
  },
];

export default function App() {
  const [active, setActive] = useState(null);
  const game = GAMES.find((g) => g.id === active);

  return (
    <>
      {/* ── NAV ── */}
      <nav className="nav">
        <div className="logo">
          🕹️ <span>ARCADE</span>
        </div>
        {active && (
          <button className="back-btn" onClick={() => setActive(null)}>
            ← All Games
          </button>
        )}
      </nav>

      {/* ── HOME ── */}
      {!active && (
        <div key="home">
          <div className="hero">
            <h1>
              Mini <em>Arcade</em>
            </h1>
            <p>// three games · no downloads · pure fun</p>
          </div>
          <div className="grid">
            {GAMES.map((g) => (
              <GameCard
                key={g.id}
                icon={g.icon}
                title={g.title}
                desc={g.desc}
                onPlay={() => setActive(g.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* ── ACTIVE GAME ── */}
      {active && (
        <div className="game-wrap" key={active}>
          <div className="gtitle">
            {game.icon} {game.title}
          </div>
          <div className="gsub">
            {active === "guess"
              ? "// select your range, then start guessing"
              : active === "rps"
              ? "// you vs the machine"
              : "// find all 8 pairs"}
          </div>
          {active === "guess" && <GuessGame />}
          {active === "rps" && <RPSGame />}
          {active === "memory" && <MemoryGame />}
        </div>
      )}
    </>
  );
}
